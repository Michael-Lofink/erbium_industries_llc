# Session 4: Music Cues

Instrumental scene cues below, with your existing vocal track retained for the timed interior walk. Spotify catalogue links were checked on 8 November 2026.

| Scene | Track | Length | Cue |
| --- | --- | --- | --- |
| Fresh-Breath exterior / supplies | [Cydonia](https://open.spotify.com/track/09apQdrRojzAS1SeWLcDQb?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=7b5ec960-c667-4c16-b8e5-d89d0b40b57f) · Inon Zur | 4:16 | Keep your existing arrival cue; reuse it while bargaining for supplies. |
| Timed interior walk | [Who's Ready for Tomorrow](https://open.spotify.com/track/4mn5HdatHKN7iFGDes9G8i?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=5e0cd708-a84e-4f5b-8690-0cd27e6d09d8) · RAT BOY, IBDY | 1:56 | Keep the existing 1:56 vocal cue and your timed narration. |
| Clinic: Nera and Chief | [Home](https://open.spotify.com/track/40E0DYxwAh5L3PDDY90hV4?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=31b1311d-f19e-496e-b95f-bb8388502e92) · Michael McCann | 2:17 | A subdued electronic cue for the examination and private conversation; loop quietly. |
| A. Sop's office | [Detroit City Ambient (Part 1)](https://open.spotify.com/track/0XUBDdyDYXnbozXj5Mtkrk?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=4998165f-7023-4478-93dd-70a031777f8e) · Michael McCann | 2:03 | Low industrial tension under the questioning and PPPPP's arguments; loop quietly. |
| Travel into the cave / exploration | [The Uncertainty Principle](https://open.spotify.com/track/74Me8e65iEdkjwNfLXt3Vi?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=9e43e348-7ca1-4449-863e-b5f3a9d3a580) · Andrew Prahlow | 3:27 | Start as the cave becomes the focus; retain for navigation and observation experiments. |
| Electrovore encounter | [Robot Getaway](https://open.spotify.com/track/2xP3RG5GgWFGy9SZRox6KO?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=48dab3b9-3f78-4bd1-be14-0f6f3c5a30d7) · Sophus Alf, Troels Rohde Jørgensen | 2:56 | First choice. Start on initiative; its driving electronic rhythm suits the shifting cover and electrical attacks. Loop through combat. |
| Electrovore encounter: alternate | [Attack of the Glyphids](https://open.spotify.com/track/58RxGt45xfBb9vzIIpVdJf?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=749ca287-3553-44b5-a00b-d39e906afb23) · Sophus Alf, Troels Rohde Jørgensen | 2:13 | Use for a more urgent creature-attack feel, or alternate with Robot Getaway during a longer fight. |
| Anomaly revealed | [The Nomai](https://open.spotify.com/track/3zWTP6thyHCj8FVAMoFT4d?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=a60d944a-ec7d-4a43-9d71-bcdead018bcf) · Andrew Prahlow | 3:54 | Keep the existing cue; start when Q3 opens onto the grotto. |
| Contact and shared vision | [The Ash Twin Project](https://open.spotify.com/track/4RgYLomGIqt5iKhnWVNQPx?utm_source=openai&utm_medium=chatgpt&go=1&nap_web=1&request_id=a8f4981d-b741-43c7-8e26-d2d84394ee01) · Andrew Prahlow | 3:54 | Keep the existing cue; start on contact. Fade after the return to the gallery. |

**For this session:** Cydonia → Who's Ready for Tomorrow → Home → Detroit City Ambient (Part 1) → Cydonia → The Uncertainty Principle → Robot Getaway. The anomaly cues remain ready for a later session if the first fight fills tonight's remaining time.

The new suggestions are soundtrack selections; loop transitions and volume levels need a brief check on your playback setup.

